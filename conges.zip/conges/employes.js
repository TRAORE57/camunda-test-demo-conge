const { Client, logger } = require('camunda-external-task-client-js');
const open = require('open');
// configuration pour le client:
// - 'baseUrl': URL du Process Engine
// - 'logger': utilitaire pour enregistrer automatiquement les événements importants
// - 'asyncResponseTimeout': long délai d'interrogation (puis une nouvelle requête sera émise)
const config = { baseUrl: 'http://localhost:8080/engine-rest', use: logger, asyncResponseTimeout: 10000 };

// create a Client instance with custom configuration
const client = new Client(config);

// rejet FORMULAIRE 
client.subscribe('messageRej', async function({ task, taskService }) {
  // ajout de la logique metier ici

  // Obtention ou recuperation d'une ou de variable de processus
  const nom = task.variables.get('nom');
  const nombredemois = task.variables.get('nombredemois');
// AFFICHAGE D'INFORMATIONS 
  console.log(`BONJOUR MOONSIEUR / MADAME ${nom}. VOTRE DEMANDE A ETE REJETE 
  			   CAR VOUS DEMANDEZ PLUS DE 3 MOIS DE CONGES. MERCI DE MODIFIER 
  		LA VALEUR '${nombredemois}' ENTREE LORS DU REMPLISSAGE DU FORMULAIRE`);
  //open('https://docs.camunda.org/get-started/quick-start/success');

  // Complete the task
  await taskService.complete(task);
});

// accepter demande 
client.subscribe('approuve', async function({ task, taskService }) {
  // ajout de la logique metier ici

  // Obtention ou recuperation d'une ou de variable de processus
  const nom = task.variables.get('nom');
  const nombredemois = task.variables.get('nombredemois');
// AFFICHAGE D'INFORMATIONS 
  console.log(`BONJOUR MOONSIEUR / MADAME ${nom}; VOTRE DEMANDE A ETE ACCORDEE. 
  			   NOUS VOUS SOUHAITONS DE PASSER DE TRES BON CONGES PENDANT LES '${nombredemois}' MOIS`);
  //open('https://docs.camunda.org/get-started/quick-start/success');

  // Complete the task
  await taskService.complete(task);
});


client.subscribe('messageRefus', async function({ task, taskService }) {
  // ajout de la logique metier ici

  // Obtention ou recuperation d'une ou de variable de processus
  const nom = task.variables.get('nom');
  const nombredemois = task.variables.get('nombredemois');
// AFFICHAGE D'INFORMATIONS 
  console.log(`BONJOUR MOONSIEUR / MADAME ${nom}; VOTRE DEMANDE DE 
  			   CONGES DE '${nombredemois}' MOIS  A ETE REFUSEE PAR 
  			   LE DRH POUR DES RAISONS DE NON-CONFORMITE AU CODE DU TRAVAIL`);
  //open('https://docs.camunda.org/get-started/quick-start/success');

  // Complete the task
  await taskService.complete(task);
});